
public class Variables {

	public static void main(String[] args) {
		int edad=35;
		System.out.println(edad);

	}

}
