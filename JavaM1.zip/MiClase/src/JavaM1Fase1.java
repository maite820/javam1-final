
public class JavaM1Fase1 {

	public static void main(String[] args) {
		// mostrar a pantalla cognom1 + cognom2 + nom 
		String Cognom1, Cognom2, Nom;
		Cognom1="Rodr�guez";
		Cognom2="Cap�n";
		Nom="Maite";
		System.out.print(Cognom1+" "+Cognom2+" "+Nom+"\n");
		
		//mostrar dia/mes/any
		
		String Dia, Mes, Any;
		Dia="12";
		Mes="01";
		Any="2021";
		System.out.print(Dia+"/"+Mes+"/"+Any);

	}
	
}
