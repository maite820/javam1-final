import java.util.*;

public class Javam1fase3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		boolean x = true;

		Scanner sc = new Scanner(System.in);
		System.out.println("introduir any inici, gracies");
		int a = sc.nextInt();

		int b = 0;
		for (int i = a; i <= 1971; i++) {
			if (((i % 4 == 0) && (i % 100 != 0)) || (i % 400 == 0)) {

				b++;
			}
		}

		System.out.println("Els anys de traspas son " + b);
		
	 
	  if (((a % 4 == 0) && (a % 100 != 0)) || (a % 400 == 0)) {
	  System.out.print("�l'any "+a +"es un any de traspas"+x); } 
	 else {
	 System.out.print(+a+" "+"no es un any de traspas" );
	 }
	  sc.close();
	 }
	}


