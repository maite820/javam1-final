import java.util.Scanner;

public class javaM1fase4 {
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String Cognom1, Cognom2, Nom;
		Cognom1 = "Rodr�guez";
		Cognom2 = "Cap�n";
		Nom = "Maite";
		

		Scanner sc = new Scanner(System.in);
		System.out.println("introduir any de naixement, gracies");
		int a = sc.nextInt();

		// mostrar dia/mes/any

		String Dia, Mes;
		int Any;
		Dia = "12";
		Mes = "01";
		Any = a;

		if (((a % 4 == 0) && (a % 100 != 0)) || (a % 400 == 0)) {
			System.out.print(Cognom1 + " " + Cognom2 + " " + Nom + "\n");
			System.out.print(Dia + "/" + Mes + "/" + Any+"\n");
			System.out.print(", " + a + "es un any de traspas");
		} else {
			System.out.print(Cognom1 + " " + Cognom2 + " " + Nom + "\n");
			System.out.print(Dia + "/" + Mes + "/" + Any+ "\n");
			System.out.print(" " + "no es un any de traspas");
		}
		sc.close();
	}
}
